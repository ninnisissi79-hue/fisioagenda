/*
 * FisioAgenda pilota — collegamento al TUO progetto Supabase.
 * Prima di trascinare la cartella su Netlify, sostituisci i due valori qui sotto
 * (Supabase → Project Settings → API Keys / Data API):
 *   - supabaseUrl: il "Project URL", es. https://abcdefgh.supabase.co
 *   - supabaseKey: la chiave PUBBLICA "Publishable key" (sb_publishable_…) oppure "anon public".
 * NON inserire mai la chiave "secret" o "service_role", né password.
 */
window.FA_CONFIG = {
  supabaseUrl: 'INSERISCI_QUI_IL_PROJECT_URL',
  supabaseKey: 'INSERISCI_QUI_LA_PUBLISHABLE_KEY'
};
