window.FA_CONFIG = { supabaseUrl: "https://cihywdeiyrawgcglxbcg.supabase.co", supabaseKey: "sb_publishable_K0v-212l6UQ0dnv75i0Vkw_ad1qz_N9" };
