# FisioAgenda pilota — configurazione passo per passo

Servono **un servizio esterno gratuito**, cioè **Supabase** (database, account e aggiornamento in tempo reale), e in un secondo momento, solo se lo chiederai, un sito statico (per esempio un **nuovo** progetto Netlify gratuito).
**Costi: 0 €** con i piani gratuiti. Non attivare piani a pagamento: Supabase Pro costa circa 25 $/mese e non serve per il pilota.

> Le voci dei menu di Supabase cambiano nel tempo: se un nome non corrisponde, cerca la voce equivalente.

## 1. Crea il progetto Supabase (circa 5 minuti)

1. Vai su https://supabase.com e crea un account gratuito. È possibile accedere anche con GitHub.
2. **New project**:
   - **Name:** `fisioagenda-pilota`
   - **Database password:** premi *Generate*, salvala nel tuo gestore di password e **non inviarla a nessuno**, nemmeno a me.
   - **Region:** una regione europea, per esempio *Central EU (Frankfurt)*.
   - **Plan:** Free.
   - Opzioni di sicurezza consigliate (compatibili con il pilota): **Data API attiva**, **RLS automatica attiva**, **esposizione automatica delle nuove tabelle disattivata**. Le autorizzazioni necessarie sono concesse esplicitamente dallo script, solo in lettura per gli utenti autenticati.
3. Attendi che il progetto sia pronto (1–2 minuti).

## 2. Installa il database (2 minuti)

1. Nel progetto apri **SQL Editor → New query**.
2. Copia **tutto** il contenuto di [`supabase/setup-completo.sql`](supabase/setup-completo.sql), incollalo e premi **Run**. Il risultato atteso è “Success. No rows returned”.
   Se avevi già eseguito una versione precedente dello script (senza la parte `20261005000003_grants`), esegui soltanto [`supabase/migrations/20261005000003_grants.sql`](supabase/migrations/20261005000003_grants.sql): si può ripetere senza problemi.
3. Nuova query: copia il contenuto di [`supabase/seed.sql`](supabase/seed.sql) (dati dimostrativi **fittizi**) e premi **Run**.

## 3. Blocca la registrazione libera

1. **Authentication → Sign In / Providers** (o *Providers*): disattiva **Allow new users to sign up**. Lascia attivo il provider *Email*.
2. **Authentication → URL Configuration → Site URL**: per ora lascia il valore attuale; lo aggiorneremo quando ci sarà l'indirizzo del sito.

## 4. Crea gli account (coordinatore e colleghi)

L'email integrata di Supabase invia messaggi solo ai membri del team: per questo gli account si creano con una **password temporanea**.

1. **Authentication → Users → Add user → Create new user**: inserisci l'email, una password temporanea e spunta **Auto Confirm User**.
2. Fai così prima per te, poi per ogni collega.
3. Solo per te, una volta: in **SQL Editor** esegui la riga seguente (con la tua email):
   ```sql
   select app.set_first_admin('tua.email@esempio.it');
   ```
4. Nell'app, sezione **Configurazione → Utenti**, assegna ai colleghi il ruolo *Operatore* o *Sola consultazione*. I nuovi account partono in sola consultazione.
5. Comunica a ogni collega la password temporanea **di persona**, non per email insieme all'indirizzo del sito. Al primo accesso ognuno la cambia con il pulsante **Password** in alto.

Per disattivare un collega: **Configurazione → Utenti → togli “Attivo”**. L'accesso viene bloccato subito anche sul server.

## 5. Dammi i due dati pubblici (quando vuoi procedere)

Da **Project Settings → API Keys** (o *Data API*) servono:
- **Project URL**, del tipo `https://xxxxxxxx.supabase.co`;
- **Publishable key**, che inizia con `sb_publishable_…`, oppure in alternativa la chiave *anon public*.

Sono dati **pubblici per progetto**: la protezione è data dagli account e dai permessi sul server.
**Non inviare mai** la *secret key*, la chiave *service_role* o la password del database.

Con questi due dati preparo il pacchetto del sito (`npm run build` con `FA_URL` e `FA_KEY`) e lo provo collegato al tuo progetto. La pubblicazione avverrà **solo su tua richiesta**, in un **nuovo** progetto Netlify separato. I siti esistenti non vengono toccati. Dopo la pubblicazione andrà aggiornato il *Site URL* indicato al passo 3.

## Aggiornare un database già installato

Se il database era stato installato con una versione precedente, esegui una volta [`supabase/aggiornamento-database.sql`](supabase/aggiornamento-database.sql) (SQL Editor → New query → incolla → Run). Si può rieseguire senza problemi e non tocca i dati. Senza questo passo l'app funziona, ma la pagina **Importa tabulato** chiede di aggiornare il database.

## Importare i tabulati cartacei

**Costi e privacy.** Il sito **non invia le foto a nessun servizio**: restano sul computer e servono solo per il confronto accanto ai dati. La lettura delle foto la fa Claude **in chat**, cioè con lo strumento che già usi (nessuna chiave, nessun servizio da configurare, nessun costo aggiuntivo). Manda solo foto con i nomi già sostituiti, come hai fatto per gli esempi.

1. **Mandami le foto** dei tabulati in chat. Ti restituisco un file di trascrizione `.json` per ogni foto: numeri, R, V, orari e giorni come li leggo, con le **caselle incerte segnalate** (mai inventate).
2. Nell'app apri **Importa tabulato → Scegli foto e trascrizione…** e seleziona insieme la foto e il file `.json`. Puoi anche scegliere **più file insieme** o direttamente lo **zip** con tutte le trascrizioni: si apre una scheda per ogni tabulato, da importare uno alla volta.
3. Controlla **fisioterapista, mese, “Importa dal”** e percorso. La **Durata predefinita delle sedute** (30 minuti, 45 minuti, 1 ora o altro) è già proposta: vale per i pazienti a cui non ne scegli un’altra. Durate diverse sullo stesso foglio vanno benissimo.
4. **Anteprima:** a sinistra la foto, a destra una riga per paziente con le caselle del mese. Clicca una casella: il punto corrispondente si evidenzia sulla foto.
   - In **giallo** le letture incerte: correggi il valore o conferma con ✓ (oppure “Accetta le letture incerte” per tutto il foglio).
   - **Durata della seduta** (nella riga): per quel paziente. **Modifica singole sedute** (sotto la riga): orario, durata e chi fa ogni singola seduta, oppure “Non importare questa seduta”.
   - Numero sul tabulato a ritroso: **seduta n. = 11 − numero** (cicli da 10). Il numero originale resta salvato su ogni seduta. Se la numerazione risale senza un “1” prima, l’app lo considera un nuovo ciclo e lo segnala (correggi la casella se era un errore di lettura).
   - **«//»** dopo il nome = fine ciclo. **R** = recupero; **V** = visita fisiatrica (promemoria, non è una seduta).
   - Le caselle prima di “Importa dal” non diventano appuntamenti: servono a sapere a che seduta è il paziente. Le sedute già passate entrano **programmate**.
   - Se un nome esiste già in archivio, scegli se è lo stesso paziente (continua il suo ciclo o ne apre uno nuovo) o un omonimo.
   - **Avvisi** (giallo: fuori orario, assenza, chiusura, fascia piena): non bloccano. Nel riquadro **4. Conferma** spunti “Importa comunque le sedute con avvisi” (finiranno in “Da sistemare”); se non spunti, restano fuori e te le ripropongo con il motivo.
   - **Conflitti** (rosso: due pazienti alla stessa ora): solo quella seduta resta fuori, il resto della riga si importa. La sistemi con “Modifica singole sedute”.
   - Una riga resta fuori solo se manca davvero qualcosa (nome, orario, lettura incerta da confermare, omonimo da scegliere): il motivo è scritto in rosso nella riga e nell’elenco della Conferma, con il link alla riga.
   - **Sostituzioni sul foglio — sigle** sotto i numeri (es. MG): per ogni sigla scegli il collega (la seduta va nel suo calendario come sostituzione), “Importa nel calendario del titolare” oppure “Non importare queste sedute”.
   - **Sostituzioni sul foglio — pazienti di colleghi** (nomi scritti in un giorno solo): per ognuno scegli **Importa** o **Non importare**. Se importi, completa paziente (in trattamento, in archivio o nuovo), fisioterapista titolare, sostituto, data, ora e durata. “+ Stessa sostituzione in un altro giorno” se il paziente è stato trattato più volte. Nessun doppione: se il paziente ha già un appuntamento quel giorno non se ne crea un altro. Finché non scegli, la sostituzione non viene importata (il resto sì).
   - **Assenze segnate sul foglio** (F ferie, M malattia, P permesso): si registrano solo con il pulsante **Registra**.
5. **Importa nel calendario.** Ogni riga si salva per conto suo: se una riga ha un problema, le altre sono comunque salvate e in alto trovi il riepilogo con **cosa non è entrato e perché** (riga, giorno, motivo). Le tue correzioni restano sul foglio: sistemi e premi di nuovo “Importa”, senza doppioni. Per le sedute rimaste fuori di un paziente importato c’è “Correggi e riprova queste sedute”.
6. Ricaricare la stessa foto o lo stesso foglio non crea doppioni. Ogni importazione compare in **Importazioni recenti** con il pulsante **Annulla**.

Per provare senza dati reali: crea un fisioterapista di nome **Fittizio** e importa [`esempi/tabulato-fittizio.png`](esempi/tabulato-fittizio.png) con [`esempi/tabulato-fittizio.json`](esempi/tabulato-fittizio.json).

## Gestire gli appuntamenti dal calendario del collega

- **+ Aggiungi paziente** (in alto nel calendario): fisioterapista e giorno sono già quelli del calendario aperto, ma si possono cambiare.
- **Pazienti in trattamento**: elenco dei pazienti del collega (o di tutti), con sedute fatte, programmate e prossima seduta. “+ Seduta” aggiunge una seduta al **suo** ciclo, senza nuova anagrafica né nuovo ciclo, con **durata della seduta** a scelta (30, 45, 60 o altro, solo per quella seduta). Se il ciclo ha già tutte le sedute, diventa una seduta in più.
- Cliccando un punto libero del calendario conta **l’orario esatto** del clic (a passi di 15 minuti).
- **Trascina** una seduta per cambiare giorno o ora. Rosso = sovrapposizione (non si sposta); giallo = avviso (fuori orario, assenza…): ti chiede conferma.
- **Clicca una seduta → Modifica: giorno, ora, durata, fisioterapista** (solo quella seduta): ora libera (con i posti liberi suggeriti), durata 30/45/60/altro, collega. Un collega diverso dal titolare = **sostituzione** (il ciclo resta del titolare); tornare al titolare la annulla. Il controllo è immediato: un conflitto dice con chi; un avviso si conferma con “Salva comunque”. Quello che hai scritto non si perde.
- **Clicca una seduta → ✎ Correggi:** nome del paziente, “questa è la seduta n. … di …”, tipo di trattamento (GC, RM…), durata delle sedute del ciclo (questa e le prossime), visita fisiatrica, **elimina** una seduta inserita per errore.
- Nel calendario del sostituto la seduta ha il bordo azzurro e “sostituisce …”; nel calendario del titolare resta un promemoria tratteggiato “→ con … (sostituzione)”.

## Sostituzioni

Menu **Sostituzioni**: tutte le sostituzioni del periodo scelto, raggruppate per giorno e per fisioterapista assente.

- Per ogni seduta: orario, paziente, durata, titolare, sostituto e stato: **da assegnare** (titolare assente, nessun sostituto) o **confermata**.
- **Chi prende i pazienti**: per ogni titolare, quante sedute vanno a ciascun collega e quante sono ancora da assegnare.
- **Assegna / Cambia sostituto**: scegli il collega nell’elenco (accanto al nome: ✓ libero, ⚠ avviso, ✗ occupato) e conferma.
- **Annulla sostituzione**: la seduta torna al titolare (se è assente resta “da assegnare”).
- **Modifica orario / durata**: apre la seduta. **Proponi i sostituti in automatico**: il piano delle assenze già esistente.
- Le modifiche fatte qui, nel calendario o nell’importazione si vedono subito in tutte le schermate.

## Backup e ripristino

Il piano gratuito **non** include backup automatici scaricabili. Procedura consigliata:

- **Settimanale (dall'app, coordinatore):** **Configurazione → Backup → Scarica backup**. Conserva il file `.json` in una cartella sicura.
- **Ripristino:** **Configurazione → Backup → scegli il file**, scrivi `RIPRISTINA` e conferma. Prima del ripristino l'app scarica automaticamente una copia dello stato attuale. Il ripristino sostituisce i dati del servizio per tutti i colleghi; account e storico restano, e il ripristino è registrato nello storico.
- **Copia completa del database (facoltativa, per chi usa il terminale):** in **Project Settings → Database → Connection string** copia la stringa *Session pooler*, poi:
  ```
  pg_dump "postgresql://postgres.xxxx:PASSWORD@…pooler.supabase.com:5432/postgres" --schema=public --schema=app -Fc -f fisioagenda.dump
  pg_restore --clean --if-exists -d "<stessa stringa>" fisioagenda.dump
  ```
  La password va digitata solo sul tuo computer.

## Se qualcosa non va

- **“Connessione assente”** (banner rosso): le modifiche non vengono salvate. Riprova quando torna la rete; nulla viene mostrato come confermato prima del salvataggio.
- **“Modificato nel frattempo da …”**: un collega ha cambiato lo stesso dato. I dati sono già stati ricaricati: controlla e ripeti.
- **“Il posto è stato appena prenotato da un altro utente”**: ripeti la ricerca.
- **Il sito non si collega dopo una settimana di inattività:** il progetto gratuito è in pausa. Riattivalo dal pannello Supabase con *Restore project*.
